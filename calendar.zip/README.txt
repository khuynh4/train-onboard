1. Make sure you have the pip management tool [https://pypi.org/project/pip/]
2. Have a project created on the Google Cloud Platform [https://developers.google.com/workspace/guides/create-project]
3. Authorize credentials
4. Run in command line:  pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib (gets you Google client library)
5. Run calendar.py
